package com.example.budgettracker;

public class Account {

    private int    id;
    private String name;
    private String type; // e.g., "Checking", "Savings"
    private double balance;

    // Default constructor
    public Account() {}

    // Full constructor
    public Account(int id, String name, String type, double balance) {
        this.id      = id;
        this.name    = name;
        this.type    = type;
        this.balance = balance;
    }

    // ── Getters ──────────────────────────────────────────────
    public int    getId()      { return id; }
    public String getName()    { return name; }
    public String getType()    { return type; }
    public double getBalance() { return balance; }

    // ── Setters ──────────────────────────────────────────────
    public void setId(int id)              { this.id      = id; }
    public void setName(String name)       { this.name    = name; }
    public void setType(String type)       { this.type    = type; }
    public void setBalance(double balance) { this.balance = balance; }
}
