package com.example.budgettracker;

import static java.lang.String.*;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TransactionsAdapter extends RecyclerView.Adapter<TransactionsAdapter.ViewHolder> {

    // Interface so MainActivity can handle edit and delete clicks
    public interface OnTransactionActionListener {
        void onEdit(Transaction transaction);
        void onDelete(Transaction transaction);
    }

    private final List<Transaction>           transactionList;
    private final OnTransactionActionListener listener;
    private final DatabaseHelper              dbHelper;

    public TransactionsAdapter(List<Transaction> transactionList, OnTransactionActionListener listener, DatabaseHelper dbHelper) {
        this.transactionList = transactionList;
        this.listener        = listener;
        this.dbHelper        = dbHelper;
    }

    // ── ViewHolder ────────────────────────────────────────────
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvAmount, tvType, tvCategory, tvDate, tvDescription, tvAccount;
        Button   btnEdit, btnDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            tvAmount      = itemView.findViewById(R.id.tvAmount);
            tvType        = itemView.findViewById(R.id.tvType);
            tvCategory    = itemView.findViewById(R.id.tvCategory);
            tvDate        = itemView.findViewById(R.id.tvDate);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvAccount     = itemView.findViewById(R.id.tvAccount);
            btnEdit       = itemView.findViewById(R.id.btnEdit);
            btnDelete     = itemView.findViewById(R.id.btnDelete);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_transaction, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Transaction transaction = transactionList.get(position);

        // Get account name
        Account account = dbHelper.getAccountById(transaction.getAccountId());
        String accountName = account != null ? account.getName() : "Unknown";

        // Bind data to views
        holder.tvAmount.setText(format("$%.2f", transaction.getAmount()));
        holder.tvType.setText(transaction.getType());
        holder.tvCategory.setText(transaction.getCategory() != null ? transaction.getCategory() : "");
        holder.tvDate.setText(transaction.getDate());
        holder.tvDescription.setText(transaction.getDescription() != null ? transaction.getDescription() : "");
        holder.tvAccount.setText(accountName);

        // Wire up click listeners — delegate to MainActivity
        holder.btnEdit.setOnClickListener(v -> listener.onEdit(transaction));
        holder.btnDelete.setOnClickListener(v -> listener.onDelete(transaction));
    }

    @Override
    public int getItemCount() {
        return transactionList.size();
    }
}
