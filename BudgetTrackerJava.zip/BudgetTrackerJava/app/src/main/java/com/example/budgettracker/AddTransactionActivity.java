package com.example.budgettracker;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddTransactionActivity extends AppCompatActivity {

    private TextInputEditText etAmount, etType, etCategory, etDate, etDescription, etAccount, etToAccount;
    private DatabaseHelper    dbHelper;

    private boolean isEditMode = false;
    private int     editId     = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_transaction);

        dbHelper      = new DatabaseHelper(this);
        etAmount      = findViewById(R.id.etAmount);
        etType        = findViewById(R.id.etType);
        etCategory    = findViewById(R.id.etCategory);
        etDate        = findViewById(R.id.etDate);
        etDescription = findViewById(R.id.etDescription);
        etAccount     = findViewById(R.id.etAccount);
        etToAccount   = findViewById(R.id.etToAccount);

        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // Tap on date field opens DatePickerDialog
        etDate.setOnClickListener(v -> showDatePicker());

        // Check whether we were launched for Add or Edit
        int id = getIntent().getIntExtra(MainActivity.EXTRA_TRANSACTION_ID, -1);
        if (id != -1) {
            isEditMode = true;
            editId     = id;
            setTitle("Edit Transaction");
            populateFields(id);
        } else {
            setTitle("Add Transaction");
        }

        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(v -> saveTransaction());
    }

    // Show a calendar date picker and set the result in etDate
    private void showDatePicker() {
        Calendar cal = Calendar.getInstance();
        new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    String dateStr = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                    etDate.setText(dateStr);
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    // Pre-populate fields when editing an existing transaction
    private void populateFields(int id) {
        Transaction transaction = dbHelper.getTransactionById(id);
        if (transaction != null) {
            etAmount.setText(String.valueOf(transaction.getAmount()));
            etType.setText(transaction.getType());
            etCategory.setText(transaction.getCategory());
            etDate.setText(transaction.getDate());
            etDescription.setText(transaction.getDescription());
            etAccount.setText(String.valueOf(transaction.getAccountId()));
            if (transaction.getToAccountId() != null) {
                etToAccount.setText(String.valueOf(transaction.getToAccountId()));
            }
        }
    }

    // Validate inputs then save or update
    private void saveTransaction() {
        String amountStr   = etAmount.getText() != null ? etAmount.getText().toString().trim() : "";
        String type        = etType.getText() != null ? etType.getText().toString().trim() : "";
        String category    = etCategory.getText() != null ? etCategory.getText().toString().trim() : "";
        String date        = etDate.getText() != null ? etDate.getText().toString().trim() : "";
        String description = etDescription.getText() != null ? etDescription.getText().toString().trim() : "";
        String accountStr  = etAccount.getText() != null ? etAccount.getText().toString().trim() : "";
        String toAccountStr = etToAccount.getText() != null ? etToAccount.getText().toString().trim() : "";

        // Basic validation
        if (amountStr.isEmpty() || type.isEmpty() || date.isEmpty() || accountStr.isEmpty()) {
            Toast.makeText(this,
                    "Please fill in Amount, Type, Date, and Account.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid amount entered.", Toast.LENGTH_SHORT).show();
            return;
        }

        int accountId;
        try {
            accountId = Integer.parseInt(accountStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid account ID.", Toast.LENGTH_SHORT).show();
            return;
        }

        Integer toAccountId = null;
        if (!toAccountStr.isEmpty()) {
            try {
                toAccountId = Integer.parseInt(toAccountStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid to account ID.", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        Transaction transaction = new Transaction();
        transaction.setAccountId(accountId);
        transaction.setType(type);
        transaction.setAmount(amount);
        transaction.setCategory(category);
        transaction.setDate(date);
        transaction.setDescription(description);
        transaction.setToAccountId(toAccountId);

        if (isEditMode) {
            transaction.setId(editId);
            dbHelper.updateTransaction(transaction);
            Toast.makeText(this, "Transaction updated!", Toast.LENGTH_SHORT).show();
        } else {
            dbHelper.insertTransaction(transaction);
            Toast.makeText(this, "Transaction saved!", Toast.LENGTH_SHORT).show();
        }

        setResult(RESULT_OK);
        finish();
    }
}
