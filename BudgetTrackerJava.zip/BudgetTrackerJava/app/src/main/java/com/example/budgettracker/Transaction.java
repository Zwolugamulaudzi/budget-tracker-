package com.example.budgettracker;

public class Transaction {

    private int    id;
    private int    accountId;
    private String type; // "Deposit", "Withdrawal", "Transfer"
    private double amount;
    private String category;
    private String date;
    private String description;
    private Integer toAccountId; // For transfers, nullable

    // Default constructor
    public Transaction() {}

    // Full constructor
    public Transaction(int id, int accountId, String type, double amount, String category, String date, String description, Integer toAccountId) {
        this.id          = id;
        this.accountId   = accountId;
        this.type        = type;
        this.amount      = amount;
        this.category    = category;
        this.date        = date;
        this.description = description;
        this.toAccountId = toAccountId;
    }

    // ── Getters ──────────────────────────────────────────────
    public int       getId()          { return id; }
    public int       getAccountId()   { return accountId; }
    public String    getType()        { return type; }
    public double    getAmount()      { return amount; }
    public String    getCategory()    { return category; }
    public String    getDate()        { return date; }
    public String    getDescription() { return description; }
    public Integer   getToAccountId() { return toAccountId; }

    // ── Setters ──────────────────────────────────────────────
    public void setId(int id)                          { this.id          = id; }
    public void setAccountId(int accountId)            { this.accountId   = accountId; }
    public void setType(String type)                   { this.type        = type; }
    public void setAmount(double amount)               { this.amount      = amount; }
    public void setCategory(String category)           { this.category    = category; }
    public void setDate(String date)                   { this.date        = date; }
    public void setDescription(String description)     { this.description = description; }
    public void setToAccountId(Integer toAccountId)    { this.toAccountId = toAccountId; }
}