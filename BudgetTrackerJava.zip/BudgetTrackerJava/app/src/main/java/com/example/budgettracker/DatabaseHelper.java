package com.example.budgettracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database configuration
    private static final String DATABASE_NAME    = "banking.db";
    private static final int    DATABASE_VERSION = 2;

    // Accounts table
    public static final String TABLE_ACCOUNTS   = "accounts";
    public static final String COL_ACCOUNT_ID   = "id";
    public static final String COL_NAME         = "name";
    public static final String COL_TYPE         = "type";
    public static final String COL_BALANCE      = "balance";

    // Transactions table
    public static final String TABLE_TRANSACTIONS = "transactions";
    public static final String COL_TRANSACTION_ID = "id";
    public static final String COL_ACCOUNT_ID_FK  = "account_id";
    public static final String COL_TRANSACTION_TYPE = "type";
    public static final String COL_TRANSACTION_AMOUNT = "amount";
    public static final String COL_TRANSACTION_CATEGORY = "category";
    public static final String COL_TRANSACTION_DATE = "date";
    public static final String COL_TRANSACTION_DESCRIPTION = "description";
    public static final String COL_TO_ACCOUNT_ID = "to_account_id";

    // SQL statement to create the accounts table
    private static final String CREATE_ACCOUNTS_TABLE =
            "CREATE TABLE " + TABLE_ACCOUNTS + " (" +
            COL_ACCOUNT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_NAME       + " TEXT NOT NULL, "                     +
            COL_TYPE       + " TEXT NOT NULL, "                     +
            COL_BALANCE    + " REAL NOT NULL DEFAULT 0.0"           +
            ");";

    // SQL statement to create the transactions table
    private static final String CREATE_TRANSACTIONS_TABLE =
            "CREATE TABLE " + TABLE_TRANSACTIONS + " (" +
            COL_TRANSACTION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_ACCOUNT_ID_FK  + " INTEGER NOT NULL, "                   +
            COL_TRANSACTION_TYPE + " TEXT NOT NULL, "                    +
            COL_TRANSACTION_AMOUNT + " REAL NOT NULL, "                  +
            COL_TRANSACTION_CATEGORY + " TEXT, "                         +
            COL_TRANSACTION_DATE + " TEXT NOT NULL, "                    +
            COL_TRANSACTION_DESCRIPTION + " TEXT, "                       +
            COL_TO_ACCOUNT_ID + " INTEGER, "                             +
            "FOREIGN KEY(" + COL_ACCOUNT_ID_FK + ") REFERENCES " + TABLE_ACCOUNTS + "(" + COL_ACCOUNT_ID + "), " +
            "FOREIGN KEY(" + COL_TO_ACCOUNT_ID + ") REFERENCES " + TABLE_ACCOUNTS + "(" + COL_ACCOUNT_ID + ")" +
            ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_ACCOUNTS_TABLE);
        db.execSQL(CREATE_TRANSACTIONS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Migrate from version 1 (expenses) to version 2 (accounts and transactions)
            // For simplicity, drop old table and create new ones
            db.execSQL("DROP TABLE IF EXISTS expenses");
        }
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRANSACTIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACCOUNTS);
        onCreate(db);
    }

    // ── ACCOUNTS METHODS ─────────────────────────────────────

    // Insert account
    public void insertAccount(Account account) {
        SQLiteDatabase db     = this.getWritableDatabase();
        ContentValues  values = new ContentValues();

        values.put(COL_NAME,    account.getName());
        values.put(COL_TYPE,    account.getType());
        values.put(COL_BALANCE, account.getBalance());

        db.insertOrThrow(TABLE_ACCOUNTS, null, values);
        db.close();
    }

    // Get account by id
    public Account getAccountById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_ACCOUNTS,
                null,
                COL_ACCOUNT_ID + " = ?",
                new String[]{String.valueOf(id)},
                null, null, null
        );

        Account account = null;
        if (cursor != null && cursor.moveToFirst()) {
            account = new Account(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_ACCOUNT_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_TYPE)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COL_BALANCE))
            );
            cursor.close();
        }
        db.close();
        return account;
    }

    // Get all accounts
    public List<Account> getAllAccounts() {
        List<Account>  list   = new ArrayList<>();
        SQLiteDatabase db     = this.getReadableDatabase();
        Cursor         cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_ACCOUNTS + " ORDER BY " + COL_ACCOUNT_ID + " DESC", null);

        if (cursor.moveToFirst()) {
            do {
                Account account = new Account(
                        cursor.getInt   (cursor.getColumnIndexOrThrow(COL_ACCOUNT_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_TYPE)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COL_BALANCE))
                );
                list.add(account);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    // Update account
    public void updateAccount(Account account) {
        SQLiteDatabase db     = this.getWritableDatabase();
        ContentValues  values = new ContentValues();

        values.put(COL_NAME,    account.getName());
        values.put(COL_TYPE,    account.getType());
        values.put(COL_BALANCE, account.getBalance());

        db.update(
                TABLE_ACCOUNTS,
                values,
                COL_ACCOUNT_ID + " = ?",
                new String[]{String.valueOf(account.getId())}
        );

        db.close();
    }

    // Delete account
    public void deleteAccount(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(
                TABLE_ACCOUNTS,
                COL_ACCOUNT_ID + " = ?",
                new String[]{String.valueOf(id)}
        );
        db.close();
    }

    // ── TRANSACTIONS METHODS ──────────────────────────────────

    // Insert transaction
    public void insertTransaction(Transaction transaction) {
        SQLiteDatabase db     = this.getWritableDatabase();
        ContentValues  values = new ContentValues();

        values.put(COL_ACCOUNT_ID_FK,  transaction.getAccountId());
        values.put(COL_TRANSACTION_TYPE, transaction.getType());
        values.put(COL_TRANSACTION_AMOUNT, transaction.getAmount());
        values.put(COL_TRANSACTION_CATEGORY, transaction.getCategory());
        values.put(COL_TRANSACTION_DATE, transaction.getDate());
        values.put(COL_TRANSACTION_DESCRIPTION, transaction.getDescription());
        if (transaction.getToAccountId() != null) {
            values.put(COL_TO_ACCOUNT_ID, transaction.getToAccountId());
        }

        db.insertOrThrow(TABLE_TRANSACTIONS, null, values);
        db.close();

        // Update account balances
        updateBalancesAfterTransaction(transaction);
    }

    // Get transaction by id
    public Transaction getTransactionById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_TRANSACTIONS,
                null,
                COL_TRANSACTION_ID + " = ?",
                new String[]{String.valueOf(id)},
                null, null, null
        );

        Transaction transaction = null;
        if (cursor != null && cursor.moveToFirst()) {
            transaction = new Transaction(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_TRANSACTION_ID)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_ACCOUNT_ID_FK)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_TYPE)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COL_TRANSACTION_AMOUNT)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_CATEGORY)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_DATE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_DESCRIPTION)),
                    cursor.isNull(cursor.getColumnIndexOrThrow(COL_TO_ACCOUNT_ID)) ? null :
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_TO_ACCOUNT_ID))
            );
            cursor.close();
        }
        db.close();
        return transaction;
    }

    // Get all transactions
    public List<Transaction> getAllTransactions() {
        List<Transaction> list   = new ArrayList<>();
        SQLiteDatabase   db     = this.getReadableDatabase();
        Cursor           cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_TRANSACTIONS + " ORDER BY " + COL_TRANSACTION_ID + " DESC", null);

        if (cursor.moveToFirst()) {
            do {
                Transaction transaction = new Transaction(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_TRANSACTION_ID)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_ACCOUNT_ID_FK)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_TYPE)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COL_TRANSACTION_AMOUNT)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_CATEGORY)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_DATE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_DESCRIPTION)),
                        cursor.isNull(cursor.getColumnIndexOrThrow(COL_TO_ACCOUNT_ID)) ? null :
                            cursor.getInt(cursor.getColumnIndexOrThrow(COL_TO_ACCOUNT_ID))
                );
                list.add(transaction);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    // Get transactions for a specific account
    public List<Transaction> getTransactionsForAccount(int accountId) {
        List<Transaction> list   = new ArrayList<>();
        SQLiteDatabase   db     = this.getReadableDatabase();
        Cursor           cursor = db.query(
                TABLE_TRANSACTIONS,
                null,
                COL_ACCOUNT_ID_FK + " = ? OR " + COL_TO_ACCOUNT_ID + " = ?",
                new String[]{String.valueOf(accountId), String.valueOf(accountId)},
                null, null, COL_TRANSACTION_ID + " DESC"
        );

        if (cursor.moveToFirst()) {
            do {
                Transaction transaction = new Transaction(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_TRANSACTION_ID)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(COL_ACCOUNT_ID_FK)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_TYPE)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(COL_TRANSACTION_AMOUNT)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_CATEGORY)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_DATE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COL_TRANSACTION_DESCRIPTION)),
                        cursor.isNull(cursor.getColumnIndexOrThrow(COL_TO_ACCOUNT_ID)) ? null :
                            cursor.getInt(cursor.getColumnIndexOrThrow(COL_TO_ACCOUNT_ID))
                );
                list.add(transaction);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    // Update transaction
    public void updateTransaction(Transaction transaction) {
        SQLiteDatabase db     = this.getWritableDatabase();
        ContentValues  values = new ContentValues();

        values.put(COL_ACCOUNT_ID_FK,  transaction.getAccountId());
        values.put(COL_TRANSACTION_TYPE, transaction.getType());
        values.put(COL_TRANSACTION_AMOUNT, transaction.getAmount());
        values.put(COL_TRANSACTION_CATEGORY, transaction.getCategory());
        values.put(COL_TRANSACTION_DATE, transaction.getDate());
        values.put(COL_TRANSACTION_DESCRIPTION, transaction.getDescription());
        if (transaction.getToAccountId() != null) {
            values.put(COL_TO_ACCOUNT_ID, transaction.getToAccountId());
        }

        db.update(
                TABLE_TRANSACTIONS,
                values,
                COL_TRANSACTION_ID + " = ?",
                new String[]{String.valueOf(transaction.getId())}
        );

        db.close();

        // Update balances (this is simplified; in reality, you'd need to reverse old transaction and apply new)
        // For now, recalculate all balances
        recalculateAllBalances();
    }

    // Delete transaction
    public void deleteTransaction(int id) {
        Transaction transaction = getTransactionById(id);
        if (transaction != null) {
            SQLiteDatabase db = this.getWritableDatabase();
            db.delete(
                    TABLE_TRANSACTIONS,
                    COL_TRANSACTION_ID + " = ?",
                    new String[]{String.valueOf(id)}
            );
            db.close();

            // Reverse the transaction effect on balances
            reverseTransactionBalance(transaction);
        }
    }

    // Helper methods for balance management
    private void updateBalancesAfterTransaction(Transaction transaction) {
        Account account = getAccountById(transaction.getAccountId());
        if (account != null) {
            double newBalance = account.getBalance();
            if ("Deposit".equals(transaction.getType())) {
                newBalance += transaction.getAmount();
            } else if ("Withdrawal".equals(transaction.getType())) {
                newBalance -= transaction.getAmount();
            } else if ("Transfer".equals(transaction.getType())) {
                newBalance -= transaction.getAmount();
                if (transaction.getToAccountId() != null) {
                    Account toAccount = getAccountById(transaction.getToAccountId());
                    if (toAccount != null) {
                        toAccount.setBalance(toAccount.getBalance() + transaction.getAmount());
                        updateAccount(toAccount);
                    }
                }
            }
            account.setBalance(newBalance);
            updateAccount(account);
        }
    }

    private void reverseTransactionBalance(Transaction transaction) {
        Account account = getAccountById(transaction.getAccountId());
        if (account != null) {
            double newBalance = account.getBalance();
            if ("Deposit".equals(transaction.getType())) {
                newBalance -= transaction.getAmount();
            } else if ("Withdrawal".equals(transaction.getType())) {
                newBalance += transaction.getAmount();
            } else if ("Transfer".equals(transaction.getType())) {
                newBalance += transaction.getAmount();
                if (transaction.getToAccountId() != null) {
                    Account toAccount = getAccountById(transaction.getToAccountId());
                    if (toAccount != null) {
                        toAccount.setBalance(toAccount.getBalance() - transaction.getAmount());
                        updateAccount(toAccount);
                    }
                }
            }
            account.setBalance(newBalance);
            updateAccount(account);
        }
    }

    private void recalculateAllBalances() {
        // Reset all balances to 0
        List<Account> accounts = getAllAccounts();
        for (Account acc : accounts) {
            acc.setBalance(0.0);
            updateAccount(acc);
        }

        // Recalculate from transactions
        List<Transaction> transactions = getAllTransactions();
        for (Transaction trans : transactions) {
            updateBalancesAfterTransaction(trans);
        }
    }
}


