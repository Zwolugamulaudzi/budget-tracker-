package com.example.budgettracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity
        implements TransactionsAdapter.OnTransactionActionListener {

    public static final String EXTRA_TRANSACTION_ID = "transaction_id";

    private RecyclerView    recyclerView;
    private DatabaseHelper  dbHelper;

    // Modern approach: replaces the deprecated onActivityResult()
    private final ActivityResultLauncher<Intent> transactionLauncher =
            registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        loadTransactions(); // Refresh the list when returning
                    }
                }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper     = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create sample data if database is empty
        createSampleData();

        // Use standard Toolbar since we used NoActionBar theme
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // FAB opens AddTransactionActivity to add a new transaction
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddTransactionActivity.class);
            transactionLauncher.launch(intent);
        });

        loadTransactions();
    }

    private void createSampleData() {
        // Check if accounts exist
        List<Account> accounts = dbHelper.getAllAccounts();
        if (accounts.isEmpty()) {
            // Create sample accounts
            Account checking = new Account(0, "Checking Account", "Checking", 1000.0);
            Account savings = new Account(0, "Savings Account", "Savings", 5000.0);
            dbHelper.insertAccount(checking);
            dbHelper.insertAccount(savings);

            // Get IDs
            accounts = dbHelper.getAllAccounts();
            int checkingId = accounts.get(0).getId();
            int savingsId = accounts.get(1).getId();

            // Create sample transactions
            Transaction deposit = new Transaction(0, checkingId, "Deposit", 1000.0, "Salary", "2023-05-01", "Monthly salary", null);
            Transaction withdrawal = new Transaction(0, checkingId, "Withdrawal", 200.0, "Groceries", "2023-05-02", "Weekly groceries", null);
            Transaction transfer = new Transaction(0, checkingId, "Transfer", 500.0, "Savings", "2023-05-03", "Transfer to savings", savingsId);

            dbHelper.insertTransaction(deposit);
            dbHelper.insertTransaction(withdrawal);
            dbHelper.insertTransaction(transfer);
        }
    }

    // Load all transactions from the database and set the adapter
    private void loadTransactions() {
        List<Transaction> transactions = dbHelper.getAllTransactions();
        TransactionsAdapter adapter = new TransactionsAdapter(transactions, this, dbHelper);
        recyclerView.setAdapter(adapter);
    }

    // Called when Edit button is tapped — opens AddTransactionActivity in edit mode
    @Override
    public void onEdit(Transaction transaction) {
        Intent intent = new Intent(this, AddTransactionActivity.class);
        intent.putExtra(EXTRA_TRANSACTION_ID, transaction.getId());
        transactionLauncher.launch(intent);
    }

    // Called when Delete button is tapped — shows confirmation dialog
    @Override
    public void onDelete(Transaction transaction) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Transaction")
                .setMessage("Are you sure you want to delete this transaction?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    dbHelper.deleteTransaction(transaction.getId());
                    loadTransactions();
                    Toast.makeText(this, "Transaction deleted", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Reload list every time this activity comes back into focus
    @Override
    protected void onResume() {
        super.onResume();
        loadTransactions();
    }
}
